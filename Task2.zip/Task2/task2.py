import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# Load dataset
df = pd.read_csv("Dataset.csv")

# Handle missing cuisines
df['Cuisines'] = df['Cuisines'].fillna('Unknown')

# Combine features for recommendation (cuisine + price + rating)
df['features'] = (
    df['Cuisines'] + " " +
    df['Price range'].astype(str) + " " +
    df['Aggregate rating'].astype(str)
)

# Convert text to vectors (TF-IDF)
vectorizer = TfidfVectorizer(stop_words='english')
feature_matrix = vectorizer.fit_transform(df['features'])

# Similarity matrix
cosine_sim = cosine_similarity(feature_matrix, feature_matrix)

# Recommendation function
def recommend_restaurants(restaurant_name, top_n=5):
    if restaurant_name not in df['Restaurant Name'].values:
        return "Restaurant not found in dataset."

    idx = df[df['Restaurant Name'] == restaurant_name].index[0]
    sim_scores = list(enumerate(cosine_sim[idx]))
    sim_scores = sorted(sim_scores, key=lambda x: x[1], reverse=True)
    sim_scores = sim_scores[1:top_n+1]  # skip itself

    restaurant_indices = [i[0] for i in sim_scores]
    return df[['Restaurant Name', 'Cuisines', 'City', 'Price range', 'Aggregate rating']].iloc[restaurant_indices]

# Example usage
print(recommend_restaurants("Le Petit Souffle", top_n=5))


import streamlit as st
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# Load dataset
df = pd.read_csv("Dataset.csv")
df['Cuisines'] = df['Cuisines'].fillna('Unknown')

# Combine features
df['features'] = (
    df['Cuisines'] + " " +
    df['Price range'].astype(str) + " " +
    df['Aggregate rating'].astype(str)
)

# TF-IDF vectorization
vectorizer = TfidfVectorizer(stop_words='english')
feature_matrix = vectorizer.fit_transform(df['features'])
cosine_sim = cosine_similarity(feature_matrix, feature_matrix)

# Recommendation function
def recommend_restaurants(restaurant_name, top_n=5):
    if restaurant_name not in df['Restaurant Name'].values:
        return pd.DataFrame({"Error": ["Restaurant not found"]})

    idx = df[df['Restaurant Name'] == restaurant_name].index[0]
    sim_scores = list(enumerate(cosine_sim[idx]))
    sim_scores = sorted(sim_scores, key=lambda x: x[1], reverse=True)
    sim_scores = sim_scores[1:top_n+1]

    restaurant_indices = [i[0] for i in sim_scores]
    return df[['Restaurant Name', 'Cuisines', 'City', 'Price range', 'Aggregate rating']].iloc[restaurant_indices]

# Streamlit UI
st.title("🍴 Restaurant Recommendation System")
st.write("Get recommendations based on your favorite restaurant!")

# Dropdown for restaurant selection
restaurant_list = df['Restaurant Name'].unique()
selected_restaurant = st.selectbox("Choose a restaurant you like:", restaurant_list)

top_n = st.slider("Number of recommendations", 1, 10, 5)

if st.button("Get Recommendations"):
    recommendations = recommend_restaurants(selected_restaurant, top_n)
    st.dataframe(recommendations)
