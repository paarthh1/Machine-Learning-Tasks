import streamlit as st
import pandas as pd
import folium
from streamlit_folium import st_folium
import plotly.express as px

# Title
st.title("Task 4: Location-based Analysis of Restaurants")

# Upload CSV file
uploaded_file = st.file_uploader("Upload your dataset (CSV)", type=["csv"])

if uploaded_file is not None:
    # Load dataset
    df = pd.read_csv(uploaded_file)

    st.subheader("Dataset Preview")
    st.write(df.head())

    # Check if latitude and longitude exist
    if "Latitude" in df.columns and "Longitude" in df.columns:
        st.subheader("📍 Restaurant Distribution on Map")
        
        # Create map centered around mean location
        m = folium.Map(location=[df["Latitude"].mean(), df["Longitude"].mean()], zoom_start=12)

        # Add markers
        for i, row in df.iterrows():
            folium.Marker(
                location=[row["Latitude"], row["Longitude"]],
                popup=f"{row['Restaurant Name']} - {row.get('City','')}",
                tooltip=row["Restaurant Name"]
            ).add_to(m)

        # Show map
        st_folium(m, width=700, height=500)
    else:
        st.error("Dataset must have 'Latitude' and 'Longitude' columns.")

    # Group by City or Locality
    if "City" in df.columns:
        st.subheader("📊 Number of Restaurants by City")
        city_counts = df["City"].value_counts().reset_index()
        city_counts.columns = ["City", "Count"]
        fig = px.bar(city_counts, x="City", y="Count", title="Restaurants per City")
        st.plotly_chart(fig)

    if "Locality" in df.columns:
        st.subheader("📊 Number of Restaurants by Locality")
        locality_counts = df["Locality"].value_counts().reset_index()
        locality_counts.columns = ["Locality", "Count"]
        fig = px.bar(locality_counts.head(20), x="Locality", y="Count", title="Top 20 Localities with Most Restaurants")
        st.plotly_chart(fig)

    # Calculate statistics
    st.subheader("📈 Statistics by City")
    if "City" in df.columns and "Aggregate rating" in df.columns:
        stats = df.groupby("City").agg({
            "Aggregate rating": "mean",
            "Price range": "mean"
        }).reset_index()
        st.write(stats)

        fig = px.scatter(stats, x="Price range", y="Aggregate rating", color="City",
                         size="Aggregate rating", title="Price Range vs Rating by City")
        st.plotly_chart(fig)

    # Insights
    st.subheader("🔍 Insights")
    if "Aggregate rating" in df.columns:
        best_city = stats.loc[stats["Aggregate rating"].idxmax(), "City"]
        st.success(f"🏆 City with highest average rating: {best_city}")

    if "Price range" in df.columns:
        cheapest_city = stats.loc[stats["Price range"].idxmin(), "City"]
        st.info(f"💰 City with cheapest average price range: {cheapest_city}")


import streamlit as st
import pandas as pd
import folium
from streamlit_folium import st_folium
import plotly.express as px

# ---------------------------
# Streamlit App
# ---------------------------
st.set_page_config(page_title="Restaurant Location Analysis", layout="wide")
st.title("📍 Task 4: Location-based Analysis of Restaurants")

# Upload dataset
uploaded_file = st.file_uploader("Upload your restaurant dataset (CSV)", type=["csv"])

if uploaded_file is not None:
    # Load dataset
    df = pd.read_csv(uploaded_file)

    st.subheader("🔎 Dataset Preview")
    st.write(df.head())

    # ---------------------------
    # MAP VISUALIZATION
    # ---------------------------
    if "Latitude" in df.columns and "Longitude" in df.columns:
        st.subheader("🌍 Restaurant Distribution on Map")

        # Center map on average lat-long
        m = folium.Map(location=[df["Latitude"].mean(), df["Longitude"].mean()], zoom_start=11)

        # Add restaurant markers
        for i, row in df.iterrows():
            folium.Marker(
                location=[row["Latitude"], row["Longitude"]],
                popup=f"{row.get('Restaurant Name','')} - {row.get('City','')}",
                tooltip=row.get("Restaurant Name", "")
            ).add_to(m)

        st_folium(m, width=700, height=500)
    else:
        st.error("Dataset must have 'Latitude' and 'Longitude' columns for map visualization.")

    # ---------------------------
    # GROUP BY CITY
    # ---------------------------
    if "City" in df.columns:
        st.subheader("🏙️ Restaurants by City")
        city_counts = df["City"].value_counts().reset_index()
        city_counts.columns = ["City", "Count"]

        fig = px.bar(city_counts, x="City", y="Count", title="Number of Restaurants per City")
        st.plotly_chart(fig, use_container_width=True)

    # ---------------------------
    # GROUP BY LOCALITY
    # ---------------------------
    if "Locality" in df.columns:
        st.subheader("📌 Top 20 Localities with Most Restaurants")
        locality_counts = df["Locality"].value_counts().reset_index()
        locality_counts.columns = ["Locality", "Count"]

        fig = px.bar(locality_counts.head(20), x="Locality", y="Count",
                     title="Top 20 Localities by Restaurant Count")
        st.plotly_chart(fig, use_container_width=True)

    # ---------------------------
    # STATS BY CITY
    # ---------------------------
    if "City" in df.columns and "Aggregate rating" in df.columns and "Price range" in df.columns:
        st.subheader("📊 Average Rating & Price Range by City")

        stats = df.groupby("City").agg({
            "Aggregate rating": "mean",
            "Price range": "mean"
        }).reset_index()

        st.write(stats)

        fig = px.scatter(
            stats,
            x="Price range",
            y="Aggregate rating",
            color="City",
            size="Aggregate rating",
            title="Price Range vs Rating by City"
        )
        st.plotly_chart(fig, use_container_width=True)

        # ---------------------------
        # INSIGHTS
        # ---------------------------
        st.subheader("🔍 Insights")

        best_city = stats.loc[stats["Aggregate rating"].idxmax(), "City"]
        st.success(f"🏆 City with the highest average rating: **{best_city}**")

        cheapest_city = stats.loc[stats["Price range"].idxmin(), "City"]
        st.info(f"💰 City with the cheapest average price range: **{cheapest_city}**")
