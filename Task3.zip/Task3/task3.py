import streamlit as st
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# ---------------------------
# Streamlit App
# ---------------------------
st.set_page_config(page_title="🍴 Cuisine Recommendation", layout="wide")
st.title("🍴 Task 3: Content-Based Cuisine Recommendation System")

# Upload dataset
uploaded_file = st.file_uploader("Upload your restaurant dataset (CSV)", type=["csv"])

if uploaded_file is not None:
    # Load dataset
    df = pd.read_csv(uploaded_file)

    st.subheader("🔎 Dataset Preview")
    st.write(df.head())

    # Try to find cuisine column
    possible_cols = ["Cuisine", "Cuisines", "cuisine", "cuisines", "Cuisines Offered"]
    cuisine_col = None
    for col in possible_cols:
        if col in df.columns:
            cuisine_col = col
            break

    if cuisine_col is None:
        st.error("❌ No column for cuisines found. Please check your dataset. (Expected one of: Cuisine, Cuisines, etc.)")
    else:
        st.success(f"✅ Found cuisine column: **{cuisine_col}**")

        # Fill NaN with empty string
        df[cuisine_col] = df[cuisine_col].fillna("")

        # TF-IDF Vectorizer
        tfidf = TfidfVectorizer(stop_words="english")
        tfidf_matrix = tfidf.fit_transform(df[cuisine_col])

        # Cosine Similarity
        cosine_sim = cosine_similarity(tfidf_matrix, tfidf_matrix)

        # Restaurant name column detection
        name_col = None
        for col in ["Restaurant Name", "Name", "restaurant", "res_name"]:
            if col in df.columns:
                name_col = col
                break

        if name_col is None:
            st.error("❌ Could not find a column for restaurant names.")
        else:
            st.success(f"✅ Found restaurant name column: **{name_col}**")

            # Recommendation function
            def recommend_restaurants(selected_restaurant, num_recommendations=5):
                if selected_restaurant not in df[name_col].values:
                    return []
                idx = df[df[name_col] == selected_restaurant].index[0]
                sim_scores = list(enumerate(cosine_sim[idx]))
                sim_scores = sorted(sim_scores, key=lambda x: x[1], reverse=True)
                sim_scores = sim_scores[1:num_recommendations + 1]
                restaurant_indices = [i[0] for i in sim_scores]
                return df[name_col].iloc[restaurant_indices].tolist()

            # Dropdown to select a restaurant
            selected_restaurant = st.selectbox("Select a restaurant:", df[name_col].unique())

            if st.button("🔍 Get Recommendations"):
                recommendations = recommend_restaurants(selected_restaurant)
                if recommendations:
                    st.subheader(f"📌 Recommended restaurants similar to **{selected_restaurant}**")
                    for i, r in enumerate(recommendations, 1):
                        st.write(f"{i}. {r}")
                else:
                    st.warning("No recommendations found.")
